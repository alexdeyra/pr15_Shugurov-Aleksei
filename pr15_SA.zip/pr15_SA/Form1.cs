﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr15_SA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (x1textBox.Text == "" || x2textBox.Text == "" || y1textBox.Text == "" || y2textBox.Text == "" || z1textBox.Text == "" || z2textBox.Text == "")
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
            Vector vector1 = new Vector(double.Parse(x1textBox.Text), double.Parse(y1textBox.Text), double.Parse(z1textBox.Text));
            Vector vector2 = new Vector(double.Parse(x2textBox.Text), double.Parse(y2textBox.Text), double.Parse(z2textBox.Text));
                Vector sum = vector1 + vector2;
                Vector difference = vector1 - vector2;
                double dotProduct = vector1.DotProduct(vector2);
                double cosineSimilarity = vector1.CosineSimilarity(vector2);

                MessageBox.Show($"Сумма: ({sum.X}, {sum.Y}, {sum.Z})" +
                                $"\nРазница: ({difference.X}, {difference.Y}, {difference.Z})" +
                                $"\nТочечный продукт: {dotProduct}" +
                                $"\nКосинусное сходство: {cosineSimilarity}");
            }
        }
    }
}
